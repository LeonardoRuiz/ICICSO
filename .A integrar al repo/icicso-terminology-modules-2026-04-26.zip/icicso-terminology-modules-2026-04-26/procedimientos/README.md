# Procedimientos, intervenciones y suministros

Modulo: `procedimientos`

## Proposito
Procedimientos hospitalarios, actos medicos, quirurgicos, suministros, facturacion tecnica y codificacion operacional.

## Fuentes incluidas (3)

- **ICD-10-PCS** (`icd-10-pcs`): Procedimientos hospitalarios. Acceso: public / Acceso publico.
- **HCPCS Level II** (`hcpcs-level-ii`): Procedimientos y suministros. Acceso: public / Acceso publico.
- **CPT** (`cpt`): Procedimientos medicos y quirurgicos. Acceso: restricted / Licencia propietaria AMA.

## Estrategia de emulacion ICICSO

1. Commit inicial: solo manifiestos, esquemas, adaptadores y stubs licitos.
2. Datos reales publicos: cachear en `terminologies/modules/procedimientos/raw/<source_id>/` cuando la licencia lo permita.
3. Datos con login o licencia: resolver via variables de entorno locales, sin subir snapshots al repo.
4. Normalizacion: producir salidas internas en `terminologies/modules/procedimientos/normalized/<source_id>/`.
5. Tests: validar conteos minimos, version declarada, checksums si existen y forma canonica del registro.

## Variables de entorno sugeridas

```bash
ICICSO_ICD_10_PCS_PATH
ICICSO_HCPCS_LEVEL_II_PATH
ICICSO_CPT_PATH
```
