# ICICSO terminology modules

Paquete modular generado el 2026-04-26 a partir de `source-manifest.json`.

## Cobertura

- Fuentes en manifiesto base: 22
- Fuentes asignadas: 22
- Fuentes sin asignar: 0

## Modulos

- **Laboratorio y observaciones** (`laboratorio`): 1 fuentes. Ruta sugerida: `terminologies/modules/laboratorio`.
- **Diagnosticos y nomenclatura clinica** (`diagnosticos`): 6 fuentes. Ruta sugerida: `terminologies/modules/diagnosticos`.
- **Procedimientos, intervenciones y suministros** (`procedimientos`): 3 fuentes. Ruta sugerida: `terminologies/modules/procedimientos`.
- **Farmacos, sustancias y prescripcion** (`farmacos`): 4 fuentes. Ruta sugerida: `terminologies/modules/farmacos`.
- **Interoperabilidad clinica, documentos y autorizacion** (`interoperabilidad`): 8 fuentes. Ruta sugerida: `terminologies/modules/interoperabilidad`.

## Regla de repo

No commitear snapshots licenciados. El repo debe contener manifiestos, adaptadores, loaders, stubs y datos publicos permitidos. Para SNOMED CT, CPT, LOINC/RxNorm con cuenta, usar rutas locales o artefactos privados fuera del repositorio.
