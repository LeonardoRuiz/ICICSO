# Interoperabilidad clinica, documentos y autorizacion

Modulo: `interoperabilidad`

## Proposito
FHIR, CDA, value sets de intercambio, perfiles de implementacion y lanzamiento/autorizacion SMART.

## Fuentes incluidas (8)

- **HL7 FHIR R5 Definitions** (`hl7-fhir-r5-definitions`): Interoperabilidad clinica. Acceso: public / Acceso publico.
- **FHIR Implementation Registry** (`fhir-implementation-registry`): Interoperabilidad clinica. Acceso: public / Acceso publico.
- **HL7 Terminology (THO)** (`hl7-terminology-tho`): Terminologia de interoperabilidad. Acceso: public / Acceso publico.
- **CDA R2.0 Core** (`cda-r20-core`): Arquitectura documental clinica. Acceso: public / Acceso publico.
- **CDA Value Sets** (`cda-value-sets`): Terminologia CDA. Acceso: public / Acceso publico.
- **C-CDA on FHIR** (`c-cda-on-fhir`): Documentos clinicos y mapeo. Acceso: public / Acceso publico.
- **US Core Implementation Guide** (`us-core-implementation-guide`): Interoperabilidad FHIR en EE.UU.. Acceso: public / Acceso publico.
- **SMART App Launch** (`smart-app-launch`): Autorizacion y lanzamiento de apps. Acceso: public / Acceso publico.

## Estrategia de emulacion ICICSO

1. Commit inicial: solo manifiestos, esquemas, adaptadores y stubs licitos.
2. Datos reales publicos: cachear en `terminologies/modules/interoperabilidad/raw/<source_id>/` cuando la licencia lo permita.
3. Datos con login o licencia: resolver via variables de entorno locales, sin subir snapshots al repo.
4. Normalizacion: producir salidas internas en `terminologies/modules/interoperabilidad/normalized/<source_id>/`.
5. Tests: validar conteos minimos, version declarada, checksums si existen y forma canonica del registro.

## Variables de entorno sugeridas

```bash
ICICSO_HL7_FHIR_R5_DEFINITIONS_PATH
ICICSO_FHIR_IMPLEMENTATION_REGISTRY_PATH
ICICSO_HL7_TERMINOLOGY_THO_PATH
ICICSO_CDA_R20_CORE_PATH
ICICSO_CDA_VALUE_SETS_PATH
ICICSO_C_CDA_ON_FHIR_PATH
ICICSO_US_CORE_IMPLEMENTATION_GUIDE_PATH
ICICSO_SMART_APP_LAUNCH_PATH
```
