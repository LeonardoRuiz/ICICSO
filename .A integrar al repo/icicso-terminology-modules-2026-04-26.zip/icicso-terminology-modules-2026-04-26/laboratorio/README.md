# Laboratorio y observaciones

Modulo: `laboratorio`

## Proposito
Resultados de laboratorio, observaciones clinicas codificadas, paneles y mediciones.

## Fuentes incluidas (1)

- **LOINC** (`loinc`): Laboratorio y observaciones clinicas. Acceso: gated / Gratis con cuenta LOINC.

## Estrategia de emulacion ICICSO

1. Commit inicial: solo manifiestos, esquemas, adaptadores y stubs licitos.
2. Datos reales publicos: cachear en `terminologies/modules/laboratorio/raw/<source_id>/` cuando la licencia lo permita.
3. Datos con login o licencia: resolver via variables de entorno locales, sin subir snapshots al repo.
4. Normalizacion: producir salidas internas en `terminologies/modules/laboratorio/normalized/<source_id>/`.
5. Tests: validar conteos minimos, version declarada, checksums si existen y forma canonica del registro.

## Variables de entorno sugeridas

```bash
ICICSO_LOINC_PATH
```
