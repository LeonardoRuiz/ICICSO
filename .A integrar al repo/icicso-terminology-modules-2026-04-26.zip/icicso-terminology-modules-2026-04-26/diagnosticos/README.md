# Diagnosticos y nomenclatura clinica

Modulo: `diagnosticos`

## Proposito
Codificacion diagnostica, nomenclatura clinica general, mapeos ICD y vocabularios biomedicos para busqueda/indizacion.

## Fuentes incluidas (6)

- **SNOMED CT International Edition** (`snomed-ct-international-edition`): Nomenclatura clinica integral. Acceso: restricted / Acceso por MLDS y licencia, segun pais miembro o afiliado.
- **SNOMED CT Spanish Edition** (`snomed-ct-spanish-edition`): Edicion en espanol. Acceso: restricted / Acceso por MLDS o espacio del pais miembro.
- **ICD-11 MMS** (`icd-11-mms`): Clasificacion diagnostica. Acceso: public / Acceso publico.
- **ICD-10 a ICD-11** (`icd-10-a-icd-11`): Mapeos diagnosticos. Acceso: public / Acceso publico.
- **ICD-10-CM** (`icd-10-cm`): Clasificacion diagnostica. Acceso: public / Acceso publico.
- **MeSH** (`mesh`): Ontologia biomedica e indizacion. Acceso: public / Acceso publico.

## Estrategia de emulacion ICICSO

1. Commit inicial: solo manifiestos, esquemas, adaptadores y stubs licitos.
2. Datos reales publicos: cachear en `terminologies/modules/diagnosticos/raw/<source_id>/` cuando la licencia lo permita.
3. Datos con login o licencia: resolver via variables de entorno locales, sin subir snapshots al repo.
4. Normalizacion: producir salidas internas en `terminologies/modules/diagnosticos/normalized/<source_id>/`.
5. Tests: validar conteos minimos, version declarada, checksums si existen y forma canonica del registro.

## Variables de entorno sugeridas

```bash
ICICSO_SNOMED_CT_INTERNATIONAL_EDITION_PATH
ICICSO_SNOMED_CT_SPANISH_EDITION_PATH
ICICSO_ICD_11_MMS_PATH
ICICSO_ICD_10_A_ICD_11_PATH
ICICSO_ICD_10_CM_PATH
ICICSO_MESH_PATH
```
