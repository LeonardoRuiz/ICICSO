# Farmacos, sustancias y prescripcion

Modulo: `farmacos`

## Proposito
Medicamentos normalizados, contenido prescribible, clasificacion farmacologica y sustancias.

## Fuentes incluidas (4)

- **RxNorm Full Monthly Release** (`rxnorm-full-monthly-release`): Medicamentos y farmacos. Acceso: restricted / Requiere licencia UMLS para full release.
- **RxNorm Prescribable Content** (`rxnorm-prescribable-content`): Medicamentos prescribibles. Acceso: public / Sin licencia para esta variante.
- **ATC/DDD** (`atc-ddd`): Clasificacion de medicamentos. Acceso: gated / Busqueda publica; descarga Excel/XML requiere cuenta.
- **UNII / GSRS** (`unii-gsrs`): Identificadores de sustancias. Acceso: public / Acceso publico para fuentes publicas.

## Estrategia de emulacion ICICSO

1. Commit inicial: solo manifiestos, esquemas, adaptadores y stubs licitos.
2. Datos reales publicos: cachear en `terminologies/modules/farmacos/raw/<source_id>/` cuando la licencia lo permita.
3. Datos con login o licencia: resolver via variables de entorno locales, sin subir snapshots al repo.
4. Normalizacion: producir salidas internas en `terminologies/modules/farmacos/normalized/<source_id>/`.
5. Tests: validar conteos minimos, version declarada, checksums si existen y forma canonica del registro.

## Variables de entorno sugeridas

```bash
ICICSO_RXNORM_FULL_MONTHLY_RELEASE_PATH
ICICSO_RXNORM_PRESCRIBABLE_CONTENT_PATH
ICICSO_ATC_DDD_PATH
ICICSO_UNII_GSRS_PATH
```
